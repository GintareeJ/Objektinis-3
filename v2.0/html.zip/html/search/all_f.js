var searchData=
[
  ['samesizetupleprefixcomparator_0',['SameSizeTuplePrefixComparator',['../structstd_1_1tr1_1_1gtest__internal_1_1_same_size_tuple_prefix_comparator.html',1,'std::tr1::gtest_internal']]],
  ['samesizetupleprefixcomparator_3c_200_2c_200_20_3e_1',['SameSizeTuplePrefixComparator&lt; 0, 0 &gt;',['../structstd_1_1tr1_1_1gtest__internal_1_1_same_size_tuple_prefix_comparator_3_010_00_010_01_4.html',1,'std::tr1::gtest_internal']]],
  ['samesizetupleprefixcomparator_3c_20k_2c_20k_20_3e_2',['SameSizeTuplePrefixComparator&lt; k, k &gt;',['../structstd_1_1tr1_1_1gtest__internal_1_1_same_size_tuple_prefix_comparator_3_01k_00_01k_01_4.html',1,'std::tr1::gtest_internal']]],
  ['scoped_5fptr_3',['scoped_ptr',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scoped_5fptr_3c_20_3a_3astd_3a_3astringstream_20_3e_4',['scoped_ptr&lt; ::std::stringstream &gt;',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scoped_5fptr_3c_20const_20_3a_3astd_3a_3astring_20_3e_5',['scoped_ptr&lt; const ::std::string &gt;',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scoped_5fptr_3c_20const_20t_20_3e_6',['scoped_ptr&lt; const T &gt;',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scoped_5fptr_3c_20gtest_5fflag_5fsaver_5f_20_3e_7',['scoped_ptr&lt; GTEST_FLAG_SAVER_ &gt;',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scoped_5fptr_3c_20testing_3a_3ainternal_3a_3aparamiteratorinterface_3c_20t_20_3e_20_3e_8',['scoped_ptr&lt; testing::internal::ParamIteratorInterface&lt; T &gt; &gt;',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scoped_5fptr_3c_20testing_3a_3ainternal_3a_3atestmetafactorybase_3c_20paramtype_20_3e_20_3e_9',['scoped_ptr&lt; testing::internal::TestMetaFactoryBase&lt; ParamType &gt; &gt;',['../classtesting_1_1internal_1_1scoped__ptr.html',1,'testing::internal']]],
  ['scopedtrace_10',['ScopedTrace',['../classtesting_1_1_scoped_trace.html',1,'testing']]],
  ['skaiciavimai_11',['Skaiciavimai',['../pasirinkimai_8h.html#a8a9d606553fd627685da4bc7a17df1d6',1,'pasirinkimai.cpp']]],
  ['skaiciavimaibendras_12',['SkaiciavimaiBendras',['../pasirinkimai_8h.html#a562e761ca26d97d44c8985ba124d88e1',1,'pasirinkimai.h']]],
  ['spausdinimas_13',['Spausdinimas',['../pasirinkimai_8h.html#ab4580ba1b9ee3e53aeb0625d8e4b08db',1,'pasirinkimai.cpp']]],
  ['spausdintiifaila_14',['SpausdintiIFaila',['../pasirinkimai_8h.html#aebcbe2cc1a02be9c44fa619deac10a33',1,'pasirinkimai.h']]],
  ['staticasserttypeeqhelper_15',['StaticAssertTypeEqHelper',['../structtesting_1_1internal_1_1_static_assert_type_eq_helper.html',1,'testing::internal']]],
  ['staticasserttypeeqhelper_3c_20t_2c_20t_20_3e_16',['StaticAssertTypeEqHelper&lt; T, T &gt;',['../structtesting_1_1internal_1_1_static_assert_type_eq_helper_3_01_t_00_01_t_01_4.html',1,'testing::internal']]],
  ['string_17',['String',['../classtesting_1_1internal_1_1_string.html',1,'testing::internal']]],
  ['studentas_18',['Studentas',['../class_studentas.html',1,'']]],
  ['support_20features_19',['Underlying library support features',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md7',1,'']]],
  ['symbols_3a_20',['Exporting API symbols:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md8',1,'']]]
];
