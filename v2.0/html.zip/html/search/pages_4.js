var searchData=
[
  ['exporting_20api_20symbols_3a_0',['Exporting API symbols:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md8',1,'']]]
];
