var searchData=
[
  ['skaiciavimai_0',['Skaiciavimai',['../pasirinkimai_8h.html#a8a9d606553fd627685da4bc7a17df1d6',1,'pasirinkimai.cpp']]],
  ['skaiciavimaibendras_1',['SkaiciavimaiBendras',['../pasirinkimai_8h.html#a562e761ca26d97d44c8985ba124d88e1',1,'pasirinkimai.h']]],
  ['spausdinimas_2',['Spausdinimas',['../pasirinkimai_8h.html#ab4580ba1b9ee3e53aeb0625d8e4b08db',1,'pasirinkimai.cpp']]],
  ['spausdintiifaila_3',['SpausdintiIFaila',['../pasirinkimai_8h.html#aebcbe2cc1a02be9c44fa619deac10a33',1,'pasirinkimai.h']]],
  ['studentas_4',['Studentas',['../class_studentas.html',1,'']]]
];
