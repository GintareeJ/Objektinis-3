var searchData=
[
  ['randpaz_0',['RandPaz',['../pasirinkimai_8h.html#a9fada6745b5148a3aae8e6d21cb3d2d7',1,'pasirinkimai.cpp']]],
  ['rusiuotibendras_1',['RusiuotiBendras',['../pasirinkimai_8h.html#ac611efd6c592539adb0dff766af24ca0',1,'RusiuotiBendras(Konteineris &amp;studentai, int b, int r, int rus):&#160;pasirinkimai.h'],['../pasirinkimai_8h.html#a35c1f1dac47d163ecdbc3923ff8d0205',1,'RusiuotiBendras(std::list&lt; Studentas &gt; &amp;studentai, int b, int r, int rus):&#160;pasirinkimai.cpp']]]
];
