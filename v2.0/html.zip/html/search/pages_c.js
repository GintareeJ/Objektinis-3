var searchData=
[
  ['support_20features_0',['Underlying library support features',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md7',1,'']]],
  ['symbols_3a_1',['Exporting API symbols:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md8',1,'']]]
];
