var searchData=
[
  ['pasirinkimai_2eh_0',['pasirinkimai.h',['../pasirinkimai_8h.html',1,'']]]
];
