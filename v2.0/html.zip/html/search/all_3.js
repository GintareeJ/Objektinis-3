var searchData=
[
  ['nuskaitytiisfailobendras_0',['NuskaitytiIsFailoBendras',['../pasirinkimai_8h.html#a116fead87e8d2452b12a2b9414088c46',1,'pasirinkimai.h']]]
];
