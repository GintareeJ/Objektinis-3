var searchData=
[
  ['vardaspavarde_0',['VardasPavarde',['../pasirinkimai_8h.html#ace342f272e1d1ac9519feacae3ed4636',1,'pasirinkimai.cpp']]]
];
