var searchData=
[
  ['can_20be_20defined_3a_0',['The following macros can be defined:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md2',1,'']]],
  ['customization_20points_1',['Customization Points',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md0',1,'']]]
];
