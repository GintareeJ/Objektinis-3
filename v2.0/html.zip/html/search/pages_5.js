var searchData=
[
  ['features_0',['Underlying library support features',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md7',1,'']]],
  ['flag_20related_20macros_3a_1',['Flag related macros:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md4',1,'']]],
  ['following_20macros_20can_20be_20defined_3a_2',['The following macros can be defined:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md2',1,'']]]
];
