var searchData=
[
  ['generuotistudentufaila_0',['GeneruotiStudentuFaila',['../pasirinkimai_8h.html#a8ed3fd39a64d085a350b8e2e5a41f6b6',1,'pasirinkimai.cpp']]]
];
