var searchData=
[
  ['library_20support_20features_0',['Underlying library support features',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md7',1,'']]],
  ['logging_3a_1',['Logging:',['../dir_a3d6ed9740a7efff8a21312563c5de53.html#autotoc_md5',1,'']]]
];
