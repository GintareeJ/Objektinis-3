var files_dup =
[
    [ "pasirinkimai.h", "pasirinkimai_8h.html", "pasirinkimai_8h" ],
    [ "rusiavimas.h", "rusiavimas_8h_source.html", null ],
    [ "studentas.h", "studentas_8h_source.html", null ],
    [ "zmogus.h", "zmogus_8h_source.html", null ]
];